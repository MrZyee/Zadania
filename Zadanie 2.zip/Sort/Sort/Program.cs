﻿using System;
using System.Diagnostics;

namespace Sort
{
    class Program
    {
        static void Main(string[] args)
        {
            double bubbleSortValue = 0;
            double quickSortValue = 0;
            Stopwatch stopwatch = new Stopwatch();
            Random random = new Random();
            Console.WriteLine("Podaj wielkosc tablicy");
            int n =Convert.ToInt32(Console.ReadLine());
            int[] arr = new int[n];
            //uzupelnienie tablicy randomowymi liczbami
            for (int i = 0; i < n; i++)
            {
                arr[i] = random.Next(0, 1000000);
            }


            stopwatch.Start();
            //bublesort
            BubleSort(arr);
            stopwatch.Stop();
            bubbleSortValue = stopwatch.ElapsedMilliseconds;

            stopwatch.Reset();

            stopwatch.Start();
            //Quicksort

            QuickSort(arr, 0, arr.Length - 1);
            stopwatch.Stop();
            quickSortValue = stopwatch.ElapsedMilliseconds;

            Console.WriteLine($"Bublesort: {bubbleSortValue}");
            Console.WriteLine($"Bublesort: {quickSortValue}");
        }


        public static void BubleSort(int[] arr)
        {
            int temp = 0;
            for (int write = 0; write < arr.Length; write++)
            {
                for (int sort = 0; sort < arr.Length - 1; sort++)
                {
                    if (arr[sort] > arr [sort +1])
                    {
                        temp = arr[sort + 1];
                        arr[sort + 1] = arr[sort];
                        arr[sort] = temp;
                    }
                }
            }
        }
        public static void QuickSort(int[] array, int left, int right)
        {
            var i = left;
            var j = right;
            var pivot = array[(left + right) / 2];
            while (i < j)
            {
                while (array[i] < pivot) i++;
                while (array[j] > pivot) j--;
                if (i <= j)
                {
                    var tmp = array[i];
                    array[i++] = array[j];
                    array[j--] = tmp;
                }
            }
            if (left < j) QuickSort(array, left, j);
            if (i < right) QuickSort(array, i, right);
        }
    }
}
