﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Podaj liczbe przypadkow testowych");
            int cases;
            cases = Convert.ToInt32(Console.ReadLine());

            int[] smallBricksArray = new int[100];
            int[] bigBrickArray = new int[100];
            int[] wallArray = new int[100];
            for (int i = 0; i < cases; i++)
            {
                var value = Console.ReadLine().Split(' ');
                int tmp;

                int.TryParse(value[0], out tmp);
                smallBricksArray[i] = tmp;
                int.TryParse(value[1], out tmp);
                bigBrickArray[i] = tmp;
                int.TryParse(value[2], out tmp);
                wallArray[i] = tmp;
            }
            for (int i = 0; i < cases; i++)
            {
                int smallBricksAmount = smallBricksArray[i];
                int bigBricksAmount = bigBrickArray[i] * 5;

                if ((smallBricksAmount + bigBricksAmount) >= wallArray[i])
                    Console.WriteLine(true);
                else
                    Console.WriteLine(false);
            }
        }

    }
}
